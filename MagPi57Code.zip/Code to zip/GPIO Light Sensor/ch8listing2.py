from gpiozero import Buzzer

buzzer = Buzzer(17)
buzzer.beep()
